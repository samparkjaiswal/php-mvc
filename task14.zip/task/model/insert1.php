<?php

require "model.php";



        $first_name=$_POST['fname'];
        $last_name=$_POST['lname'];
        $email=$_POST['email'];
        $user_name=$_POST['uname'];
        $password=$_POST['pass'];
        $class=$_POST['class'];
        $section=$_POST['section'];
        $father_name=$_POST['faname'];
        $mother_name=$_POST['maname'];
        $address=$_POST['address'];
        $phone=$_POST['phone'];
        $language=$_POST['language'];
        $lang=implode(',',$language);

        $objmodel->insert_data();

?>
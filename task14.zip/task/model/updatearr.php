<?php

require 'model.php';

$data = array (
    'stuid'=>$_POST['hid'],
    'firstname'=> $_POST['fname'], 
    'lastname'=> $_POST['lname'],
    'email'=> $_POST['email'],
    'username'=> $_POST['uname'],
  //  'passkey'=> $_POST['passkey'],
    'class'=> $_POST['class'],
    'section'=> $_POST['section'],
    'fathername'=> $_POST['faname'],
    'mothername'=> $_POST['maname'],
    'address'=> $_POST['address'],
    'phone'=> $_POST['phone']
   
);


$objmodel->update($data);
?>
<?php
require "conect.php";
class modeldb extends dbconnected  
{
      public function insert_data($ins)
    {
        //taking input from form
        if(isset($_POST['submit']))
        {
     
        //insertion in basic details

        $sql_insert_bd="insert into basic(fname,lname,email,uname,pass,class,section) values('$first_name','$last_name','$email','$user_name','$password','$class','$section')";
       

        $sql_insert_bd= "INSERT INTO basic(fname,lname,email,uname,pass,class,section) VALUES ('$ins[firstname]','$ins[lastname]','$ins[email]','$ins[username]','$ins[password]','$ins[class]','$ins[section]')";

         

        $result_bd=$this->conn_var->query($sql_insert_bd);
        if(!$result_bd)
        {
           // echo "Data inserted<br>";
           echo "Data Insertion Failed in Basic Detail!<br>";
           //die(mysqli_error($sql_insert_query_runner_bd));
           die($this->conn_var->error);
        }
        
       

        //fetching student id
        $fetch_id = mysqli_insert_id($this->conn_var);

        //insertion in personal details
       

       $sql_insert_pd= "INSERT INTO personal(faname,maname,address,phone,std_id) VALUES('$ins[fathername]','$ins[mothername]','$ins[address]','$ins[phone]','$fetch_id')";

        $result_pd=$this->conn_var->query($sql_insert_pd);
        if(!$result_pd)
        {
           // echo "Data inserted<br>";
           echo "Data Insertion Failed in Personal Detail!<br>";
           //die(mysqli_error($sql_insert_query_runner_pd));
           die($this->conn_var->error);
            
        }
      
        

        //insertion in subject

    

       $language=$_POST['language'];
       $lang=implode(',',$language);

       $sql_insert_sb= "INSERT INTO subject(subject,std_id) VALUES('$lang','$fetch_id')";

        $result_sb=$this->conn_var->query($sql_insert_sb);
        if(!$result_sb)
        {
           
            echo "Data Insertion Failed in Subject Detail!<br>";
           
            die($this->conn_var->error);

        }
        else
        {
           echo "Data inserted";
            header('location: ../view/display.php');

        }
        
    }
}

    //fetch record from database

    public function display_record()
    {
        /*$sql_select="SELECT b.id, b.fname, b.lname, b.email, b.uname, b.class, b.section, p.faname, p.maname, p.address, p.phone, s.subject FROM ((basic AS b INNER JOIN personal AS p ON b.id = p.std_id) INNER JOIN subject AS s ON b.id = s.std_id)";*/

        $sql_select="SELECT * FROM ((basic INNER JOIN personal ON basic.id = personal.std_id) INNER JOIN subject ON basic.id = subject.std_id)";

        $result_sel=$this->conn_var->query($sql_select);
        if($result_sel->num_rows>0)
        {
            while($row=$result_sel->fetch_assoc())
            {
              $data[]=$row;
            }
            return $data;
        }
    }


    //delete the record
    
    public function delete_record()
    {
       
        if(isset($_GET['id']))
        {
        $id=$_GET['id'];
        $sql_del="delete from basic where id='$id'";
        $result_del=$this->conn_var->query($sql_del);
        if(!$result_del)
        {
            echo "Record Deletion Failed!<br>";
            die($this->conn_var->error);
        }
        else
        {
           // echo "Record deleted";
           header('location: ../view/display.php');
        }
         }

    }


    //for updation display record
    

    public function displayupdate()
    {
        if(isset($_GET['eid']))
        {
            $id=$_GET['eid'];
            
            $sql_sel_up="SELECT * FROM ((basic INNER JOIN personal ON basic.id = personal.std_id) INNER JOIN subject ON basic.id = subject.std_id) where id='$id'";
            $res_dis_up=$this->conn_var->query($sql_sel_up);
            if($res_dis_up->num_rows>0)
            {
                $row_upd=$res_dis_up->fetch_assoc();
                return $row_upd;
            }
        }
    }


    //update the record

    public function update($data)
    {
        if(isset($_POST['update']))
       {
           
            //updation in basic details

            $sql_update_bd="update basic set fname='$data[firstname]',lname='$data[lastname]',email='$data[email]',uname='$data[username]',class='$data[class]',section='$data[section]' where id='$data[stuid]'";

            
            $resul_bd=$this->conn_var->query($sql_update_bd);
            if(!$resul_bd)
            {
               // echo "Data inserted<br>";
               echo "Data Updation Failed in Basic Detail!<br>";
               //die(mysqli_error($sql_insert_query_runner_bd));
               die($this->conn_var->error);
            }


            //updation in personal details
            $language=$_POST['language'];
            $lang=implode(',',$language);

            $sql_update_pd="update personal set faname='$data[fathername]',maname='$data[mothername]',address='$data[address]',phone='$data[phone]' where std_id='$data[stuid]'";

            $resul_pd=$this->conn_var->query($sql_update_pd);
            if(!$resul_pd)
            {
               // echo "Data inserted<br>";
               echo "Data Updation Failed in Personal Detail!<br>";
               //die(mysqli_error($sql_insert_query_runner_bd));
               die($this->conn_var->error);
            }


            //updation in subject

            $sql_update_sb="update subject set subject='$lang' where std_id='$data[stuid]'";

            $resul_sb=$this->conn_var->query( $sql_update_sb);
            if(!$resul_sb)
            {
               // echo "Data inserted<br>";
               echo "Data Updation Failed in Subject Detail!<br>";
               //die(mysqli_error($sql_insert_query_runner_bd));
               die($this->conn_var->error);
            }
            else
            {
           echo "Data update";
            header('location: ../view/display.php');

             }

            

            
 
        }
    }


}
//create object of class
$objmodel = new modeldb();
//insert data function call
//$objmodel->insert_data();

//display the record call this function
//$data=$objmodel->display_record();

//call the display_record() function here and include this file(model.php) OR call display_record() function display.php file and include file(model.php) also.


//delete data function call
$objmodel->delete_record();

//fetch data for update form
//$objmodel->displayupdate();

//update function call but not call here call the update page
//$objmodel->update();


?>
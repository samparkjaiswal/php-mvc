<!-- Insert PHP -->

<?php

require 'model.php';

$data = array(
    'firstname'=> $_POST['fname'], 
    'lastname'=> $_POST['lname'],
    'email'=> $_POST['email'],
    'username'=> $_POST['uname'],
    'password'=> $_POST['pass'],
    'class'=> $_POST['class'],
    'section'=> $_POST['section'],
    'fathername'=> $_POST['faname'],
    'mothername'=> $_POST['maname'],
    'address'=> $_POST['address'],
    'phone'=> $_POST['phone']
    //'language'=>$_POST['language']
   
);
$objmodel->insert_data($data);
?>
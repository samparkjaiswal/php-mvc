<?php
require "../model/model.php";
if(isset($_GET['eid']))
{

$myrecord=$objmodel->displayupdate();
//print_r($myrecord);

}
$lang=$myrecord['subject'];
$langu=explode(',',$lang);
//print_r($langu);


?>


<?php

//if(isset($_POST['update']))
//{
  //$objmodel->update();
//}

?>




<html>

<head>
<center>
<h2>Update Form</h2>
</center>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="validate.js"></script>
<style>

</style>
</head>

<body>
<center>
<h3>Basic Details</h3><br>

<form action="../model/updatearr.php" id="signupForm" method="post" autocomplete="off">

<input type="hidden" name="hid" value="<?php echo $myrecord['id']; ?>"/>

First Name:<input type="text" id="fname" name="fname" value="<?php echo  $myrecord['fname']; ?>" /><br>
Last Name:<input type="text" id="lname" name="lname" value="<?php echo  $myrecord['lname']; ?>" /><br>
Email:<input type="email" name="email" id="email" value="<?php echo  $myrecord['email']; ?>" /><br>
Username:<input type="text" name="uname" id="uname" value="<?php echo  $myrecord['uname']; ?>" /><br>
<!--Password:<input type="password" name="pass" id="pass" /><br>
Confirm Password:<input type="password" name="cpass" id="cpass" /><br>-->
Class:<input type="text" name="class" id="class" value="<?php echo  $myrecord['class']; ?>" /><br>
Section:<input type="text" name="section" id="section" value="<?php echo  $myrecord['section']; ?>" /><br>

<br>

<h3>Personal Details</h3><br>
Father Name:<input type="text" name="faname" id="faname" value="<?php echo  $myrecord['faname']; ?>" /><br>
Mother Name:<input type="text" name="maname" id="maname" value="<?php echo  $myrecord['maname']; ?>" /><br>
Address:<textarea name="address" id="address" ><?php echo $myrecord['address']; ?></textarea><br>
Phone Number:<input type="tel" name="phone" id="phone" value="<?php echo  $myrecord['phone']; ?>" /><br>

<fieldset>
    <legend>
Subject:</legend>
<input type="checkbox" name="language[]"  value="Hindi"
<?php
if(in_array("Hindi",$langu))
{
    echo "checked";
}
?>
/>Hindi
<input type="checkbox" name="language[]"  value="English"

<?php
if(in_array("English",$langu))
{
    echo "checked";
}
?>

/>English
<input type="checkbox" name="language[]"   value="Math"

<?php
if(in_array("Math",$langu))
{
    echo "checked";
}
?>

/>Math
<input type="checkbox" name="language[]"  value="Punjabi" 

<?php
if(in_array("Punjabi",$langu))
{
    echo "checked";
}
?>

/>Punjabi
<input type="checkbox" name="language[]"  value="Urdu" 

<?php
if(in_array("Urdu",$langu))
{
    echo "checked";
}
?>

/>Urdu
<input type="checkbox" name="language[]"   value="Tamil" 

<?php
if(in_array("Tamil",$langu))
{
    echo "checked";
}
?>

/>Tamil
<label for="language[]" class="error" style="display:none"></label>

</fieldset>
<br><br>

<input type="submit" name="update" class="submit" value="Update"/>

</form>
</center>

</body>


</html>
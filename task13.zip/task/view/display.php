<?php
require "../model/model.php";

//$data=$objmodel->display_record();

//call the function from model.php file where this function make
//print_r($data);




?>

<html>

<head>
<h2 style="text-align:center;color:red"><u>Student Record</u></h2>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<button class="btn btn-primary fa fa-user-plus" style="margin-left:20px"> Add Student</button><br><br>
    <center>

<table class="table table-responsive" border="2px solid black" cellspacing="" style="text-align:center">
    <tr>
        <th>Id</th>
        <th>FirstName</th>
        <th>LastName</th>
        <th>Email</th>
        <th>UserName</th>
        <th>Class</th>
        <th>Section</th>
        <th>FatherName</th>
        <th>MotherName</th>
        <th>Address</th>
        <th>Phone_Number</th>
        <th>Subject</th>
        <th colspan="2">Operation</th>
</tr>




<?php



$data=$objmodel->display_record();

foreach($data as $value)
{
    echo "
    <tr style='text-align:center'>
    <td>".$value['id']."</td>
    <td>".$value['fname']."</td>
    <td>".$value['lname']."</td>
    <td>".$value['email']."</td>
    <td>".$value['uname']."</td>
    <td>".$value['class']."</td>
    <td>".$value['section']."</td>
    <td>".$value['faname']."</td>
    <td>".$value['maname']."</td>
    <td>".$value['address']."</td>
    <td>".$value['phone']."</td>
    <td>".$value['subject']."</td>
    <td><a href='update.php?eid=$value[id]' style='text-decoration:none'><button class='btn btn-warning'>Update</button></a></td>
    <td><a href='../model/model.php?id=$value[id]' style='text-decoration:none'><button class='btn btn-danger'>Delete</button></a></td>
    </tr>
    
    ";
}

?>

</table>
</center>
</body>

</html>
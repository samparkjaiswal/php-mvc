<!-- Controller -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Asap&display=swap" rel="stylesheet">
<link rel="stylesheet" href="tel.css">
    <title>Student Form</title>

    <style>
        .error {
            color: red;
        }
        #student_form {
            width: 50%;
            margin: auto;
        }

        fieldset {
            padding: 15px;
            width: 100%;
            margin: auto;
        }
        
        body {
            font-family: 'Asap', sans-serif;
        }

        h1
        {
            font-size: 45px;
            padding: 30px;
        }
        
        input::-webkit-inner-spin-button 
        {
           -webkit-appearance: none;
           margin: 0;
        }
    </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="form_jquery.js"></script>
<script src="intlTelInput-jquery.min.js"></script>
<script src="intlTelInput.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-latest.min.js"></script> -->


</head>
<body>
    <h1 style="margin: auto; width: 50%; text-align: center;">Student Form</h1>
    <form action="../Model/insert.php" id="student_form" method="POST">
        <fieldset>
            <legend>Basic Details</legend>
            <!-- First Name -->
            <label for="">First Name: </label>
            <input type= "text" name="first_name">
            <br>
            <!-- Last Name -->
            <label for="">Last Name: </label>
            <input type= "text" name="last_name">
            <br>
             <!-- Email -->
             <label for="">E-mail: </label>
            <input type= "email" name="stu_email">
            <br>
             <!-- Username -->
             <label for="">Username: </label>
            <input type= "text" name="username">
            <br>
             <!-- Password -->
             <label for="">Password: </label>
            <input type= "password" name="passkey" id="passkey">
            <br>
             <!-- Username -->
             <label for="">Confirm Password: </label>
            <input type= "password" name="con_passkey">
            <br>
             <!-- Class -->
             <label for="">Class: </label>
            <input type= "number" name="class">
            <br>
             <!-- Section -->
             <label for="">Section: </label>
            <input type= "text" name="section">
        </fieldset>

        <fieldset>
            <legend>Personal Details</legend>
            <!-- Father Name-->
            <label for="">Father Name: </label>
            <input type= "text" name="father_name">
            <br>
            <!-- Mother Name-->
            <label for="">Mother Name: </label>
            <input type= "text" name="mother_name">
            <br>
            <!-- Address-->
            <label for="">Address: </label>
            <input type= "text" name="address">
            <br>
            <!-- Phone Number-->
            <label for="">Phone Number: </label>
            <input type="tel" id="demo" placeholder="" id="telephone" name= "phone_number">
        </fieldset>

        <fieldset name="all_five">
            <legend>Subjects</legend>
            <input type="checkbox" name="checkbx_subject1">
            <label for="">Math</label>
            <input type="checkbox" name="checkbx_subject2">
            <label for="">Hindi</label>
            <input type="checkbox" name="checkbx_subject3">
            <label for="">Science</label>
            <input type="checkbox" name="checkbx_subject4">
            <label for="">Social Studies</label><br>
            <input type="checkbox" name="checkbx_subject5">
            <label for="">French</label>
            <input type="checkbox" name="checkbx_subject6">
            <label for="">German</label>
            <input type="checkbox" name="checkbx_subject7">
            <label for="">English</label>
        </fieldset>

        <button value="submit">Submit</button>
    </form>
</body>
</html>
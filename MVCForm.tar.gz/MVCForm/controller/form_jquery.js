$(document).ready(function(){

    $('#student_form').validate({
        rules: {
            first_name:{
                required: true
            },
            last_name: {
                required: true
            },
            stu_email: {
                required: true,
                email: true
            },
            username: {
                required: true
            },
            passkey:{
                required: true,
                minlength: 8
            },
            con_passkey:{
                required: true,
                minlength: 8,
                equalTo: "#passkey"
            },
            class: {
                required: true,
                range :[1, 12]
            },
            section: {
                required: true,
            },
            father_name: {
                required: true,
            },
            mother_name: {
                required: true,
            },
            address: {
                required: true,
            },
            phone: {
                required: true,
                rangelength: [10,10],
                digits: true
            },
            all_five: {
                required: true,
                minlength: 5
            }
            
        },
        messages: {
            first_name: "First Name can't be Empty",
            last_name: "Last Name can't be Empty",
            stu_email :{
                required: "Email can't be Empty",
            },
            username: "Username can't be Empty",
            phone: {
                required: "Phone Number can't be Empty",
                range: "Phone Number should be 10 character long"
            },
            section: "",
            all_five: {
                required: "Can't be empty",
                minlenght: "Select any 5 Subjects"
            }
        }
    })

    // Vanilla Javascript
var input = document.querySelector("#telephone");
window.intlTelInput(input,({
  // options here
}));

// jQuery 
$("#telephone").intlTelInput({
  // options here
});

});
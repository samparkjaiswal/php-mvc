<?php

class dbconnected {

    // member variables
     private $server= 'localhost';
     private $username = 'root';
     private $passkey = '';
     private $dbase = 'MVCDb';
     public $conn_var;

    // member functions
    public function __construct()
    {
        $this->conn_var = new mysqli($this->server,$this->username,$this->passkey,$this->dbase);

        if(!$this->conn_var){
            echo"DataBase Creation is Unsuccessful";
            die(mysqli_error($conn_var));
        }
    } 
} 

?>
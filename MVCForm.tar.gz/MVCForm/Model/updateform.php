<!-- Controller -->



<?php
    require 'model.php';

    $recived_id = $_GET['upi'];
    $sql_fetch_value = "SELECT b.stu_id, b.firstname, b.lastname, b.email, b.username, b.pswd , b.class, b.section, p.fathername, p.mothername, p.address, p.phonenumber, s.math, s.hindi, s.science, s.sst, s.french, s.german, s.english FROM `basic_details` AS b INNER JOIN `personal_details` AS p ON `b`.`stu_id` = `p`.`stuid` INNER JOIN `subjects` AS s ON `b`.`stu_id` = `s`.`stuid` WHERE `b`.`stu_id` = $recived_id";
    
    $sql_fetch_value_runner = mysqli_query($objmodel->conn_var, $sql_fetch_value);
    if(!$sql_fetch_value_runner)
    {
        echo "Query Doesn't Worked";
        die(mysqli_error($sql_fetch_value_runner));
    }
    
    $row = mysqli_fetch_row($sql_fetch_value_runner);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Asap&display=swap" rel="stylesheet">
<link rel="stylesheet" href="tel.css">
    <title>Student Updation Form</title>

    <style>
        .error {
            color: red;
        }

        #student_form {
            width: 50%;
            margin: auto;
        }

        fieldset {
            padding: 15px;
            width: 100%;
            margin: auto;
        }
        
        body {
            font-family: 'Asap', sans-serif;
        }

        h1
        {
            font-size: 45px;
            padding: 30px;
        }
        
        input::-webkit-inner-spin-button 
        {
           -webkit-appearance: none;
           margin: 0;
        }
    </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="form_jquery.js"></script>
<script src="intlTelInput-jquery.min.js"></script>
<script src="intlTelInput.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-latest.min.js"></script> -->


</head>
<body>
    <h1 style="margin: auto; width: 50%; text-align: center;">Student Updation Form</h1>
    <form action="update.php" id="student_form" method="POST">
        <fieldset>
            <legend>Basic Details</legend>
            <!-- First Name -->
            <input type= "hidden" name="stuid" value="<?php echo $row[0];?>">

            <label for="">First Name: </label>
            <input type= "text" name="first_name" value="<?php echo $row[1];?>">
            <br>
            <!-- Last Name -->
            <label for="">Last Name: </label>
            <input type= "text" name="last_name" value="<?php echo $row[2];?>">
            <br>
             <!-- Email -->
             <label for="">E-mail: </label>
            <input type= "email" name="stu_email" value="<?php echo $row[3];?>">
            <br>
             <!-- Username -->
             <label for="">Username: </label>
            <input type= "text" name="username" value="<?php echo $row[4];?>">
            <br>
             <!-- Password -->
             <label for="">Password: </label>
            <input type= "number" name="passkey" value="<?php echo $row[5];?>">
            <br>
             <!-- Class -->
             <label for="">Class: </label>
            <input type= "number" name="class" value="<?php echo $row[6];?>">
            <br>
             <!-- Section -->
             <label for="">Section: </label>
            <input type= "text" name="section" value="<?php echo $row[7];?>">
        </fieldset>

        <fieldset>
            <legend>Personal Details</legend>
            <!-- Father Name-->
            <label for="">Father Name: </label>
            <input type= "text" name="father_name" value="<?php echo $row[8];?>">
            <br>
            <!-- Mother Name-->
            <label for="">Mother Name: </label>
            <input type= "text" name="mother_name" value="<?php echo $row[9];?>">
            <br>
            <!-- Address-->
            <label for="">Address: </label>
            <input type= "text" name="address" value="<?php echo $row[10];?>">
            <br>
            <!-- Phone Number-->
            <label for="">Phone Number: </label>
            <input type="tel" id="demo" placeholder="" id="telephone" name= "phone_number" value="<?php echo $row[11];?>">
        </fieldset>

        <fieldset name="all_five">
            <legend>Subjects</legend>
            <input type="checkbox" name="checkbx_subject1" <?php if ($row[12] == 'on') echo 'checked="checked"'; ?>>
            <label for="">Math</label>
            <input type="checkbox" name="checkbx_subject2" <?php if ($row[13] == 'on') echo 'checked="checked"'; ?>>
            <label for="">Hindi</label>
            <input type="checkbox" name="checkbx_subject3" <?php if ($row[14] == 'on') echo 'checked="checked"'; ?>>
            <label for="">Science</label>
            <input type="checkbox" name="checkbx_subject4" <?php if ($row[15] == 'on') echo 'checked="checked"'; ?>>
            <label for="">Social Studies</label><br>
            <input type="checkbox" name="checkbx_subject5" <?php if ($row[16] == 'on') echo 'checked="checked"'; ?>>
            <label for="">French</label>
            <input type="checkbox" name="checkbx_subject6" <?php if ($row[17] == 'on') echo 'checked="checked"'; ?>>
            <label for="">German</label>
            <input type="checkbox" name="checkbx_subject7" <?php if ($row[18] == 'on') echo 'checked="checked"'; ?>>
            <label for="">English</label>
        </fieldset>

        <button value="submit">Submit</button>
    </form>
</body>
</html>
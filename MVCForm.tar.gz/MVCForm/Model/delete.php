<?php 
require 'model.php';
 $rec_dei= $_GET['dei'];
$objmodel->delete_data($rec_dei);
?>
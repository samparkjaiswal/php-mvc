<!-- View -->
<!-- Listing Page -->

<?php
require '../Model/model.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listing Page</title>
    <script src="https://kit.fontawesome.com/5785349af2.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<body>
<!-- Basic Details -->
<table class=" table table-primary table-striped">
  <thead>
    <tr class="table-info">
    <th colspan="7" style="font-size: 30px; text-align: center;">Basic Details</th>
    <th colspan="4" style="font-size: 30px; text-align: center;">Personal Details</th>
    <th colspan="7" style="font-size: 30px; text-align: center;">Subjects</th>
    <th colspan="7" style="font-size: 30px; text-align: center;">Action</th></tr>
    <tr class="table-primary">
      <th scope="col">Student ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">E-mail</th>
      <th scope="col">Username</th>
      <th scope="col">Class</th>
      <th scope="col">Section</th>
      <th scope="col">Father Name</th>
      <th scope="col">Mother Name</th>
      <th scope="col">Address</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Math</th>
      <th scope="col">Hindi</th>
      <th scope="col">Science</th>
      <th scope="col">SST</th>
      <th scope="col">French</th>
      <th scope="col">German</th>
      <th scope="col">English</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <?php
 $return_var= $objmodel->select_all();
//  echo var_dump($return_var);



while ($row = mysqli_fetch_assoc($return_var))
{

  print <<< HTML
   
   <tbody class="table-group-divider">
    <tr class="table-primary">
      <th scope="row">$row[stu_id]</th> <!-- Student ID-->
      <td>$row[firstname]</td> <!-- First Name-->
      <td>$row[lastname]</td> <!-- Last Name-->
      <td>$row[email]</td> <!-- E-mail-->
      <td>$row[username]</td> <!-- Username-->
      <td>$row[class]</td> <!-- Class-->
      <td>$row[section]</td> <!-- Section-->
      <td>$row[fathername]</td> <!-- Father Name-->
      <td>$row[mothername]</td> <!-- Mother Name-->
      <td>$row[address]</td> <!-- Address-->
      <td>$row[phonenumber]</td> <!-- Phone Number-->
      <td>$row[math]</td> <!-- Math-->
      <td>$row[hindi]</td> <!-- Hindi-->
      <td>$row[science]</td> <!-- Science-->
      <td>$row[sst]</td> <!-- Social Studies-->
      <td>$row[french]</td> <!-- French-->
      <td>$row[german]</td> <!-- German-->
      <td>$row[english]</td> <!-- English-->
      <td><a href="../Model/updateform.php?upi= $row[stu_id]"><i class="fa-solid fa-pencil" style="color: blue;"></i></a></td>
      <td><a href="../Model/delete.php?dei=$row[stu_id]"><i class="fa-solid fa-trash-can" style="color: red;"></i></a></td>
    </tr>
  </tbody>
  HTML;
}
  ?>
</table>
</body>
</html>